package model.parenexpressions;

import java.util.ArrayList;
import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;
import model.util.PerlinNoise;

/**
 * 
 * @author Kathleen Oshima
 * 
 * 
 */
public class YCrCbtoRGBExpression extends ParenExpression {

	public YCrCbtoRGBExpression() {
		super();
		setmyOperands(2);
	}

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("yCrCbtoRGB");
		return keywords;
	}

	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return PerlinNoise.greyNoise(getmyExpression().get(0).evaluate(map),
		        getmyExpression().get(1).evaluate(map));

	}

}
