package model.parenexpressions;

import java.util.ArrayList;
import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;
import model.util.ColorCombinations;

/**
 * 
 * @author Kathleen Oshima
 * 
 */

public class DivExpression extends ParenExpression {

	public DivExpression() {
		super();
		setmyOperands(2);
	}

	/**
	 * Combine two colors by dividing their components.
	 */

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("div");
		keywords.add("/");
		return keywords;
	}

	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return ColorCombinations.divide(getmyExpression().get(0).evaluate(map),
		        getmyExpression().get(1).evaluate(map));

	}

}
