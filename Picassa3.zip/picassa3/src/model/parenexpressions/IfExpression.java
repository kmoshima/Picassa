package model.parenexpressions;

import java.util.ArrayList;
import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;

public class IfExpression extends ParenExpression {

	public IfExpression() {
		super();
		setmyOperands(3);
	}

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("if");
		return keywords;
	}

	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		if (getmyExpression().get(0).evaluate(map)
		        .compareTo(new RGBColor(0, 0, 0)) > 0)
			return new RGBColor(getmyExpression().get(1).evaluate(map));
		return new RGBColor(getmyExpression().get(2).evaluate(map));
	}
}
