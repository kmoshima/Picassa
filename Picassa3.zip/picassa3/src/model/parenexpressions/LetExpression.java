package model.parenexpressions;

import java.util.ArrayList;

import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;

/**
 * 
 * @author Kathleen Oshima
 * 
 */
public class LetExpression extends ParenExpression {

	public LetExpression() {
		super();
		setmyOperands(3);
	}

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("let");
		return keywords;
	}

	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		map.put((getmyExpression().get(0)).getKeyword().get(0),
		        getmyExpression().get(1).evaluate(map));
		return getmyExpression().get(2).evaluate(map);
	}

}
