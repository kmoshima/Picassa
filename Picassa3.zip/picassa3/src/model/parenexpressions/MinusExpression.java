package model.parenexpressions;

import java.util.ArrayList;
import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;
import model.util.ColorCombinations;

/**
 * 
 * @author Kathleen Oshima
 * 
 */
public class MinusExpression extends ParenExpression {

	public MinusExpression() {
		super();
		setmyOperands(2);
	}

	/**
	 * Combine two colors by subtracting their components.
	 */
	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return ColorCombinations.subtract(getmyExpression().get(0)
		        .evaluate(map), getmyExpression().get(1).evaluate(map));
	}

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("minus");
		keywords.add("-");
		return keywords;
	}

}
