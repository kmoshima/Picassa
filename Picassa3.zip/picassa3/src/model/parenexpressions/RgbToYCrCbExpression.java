package model.parenexpressions;

import java.util.ArrayList;
import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;
import model.util.PerlinNoise;

/**
 * 
 * @author Kathleen Oshima
 * 
 */
public class RgbToYCrCbExpression extends ParenExpression {

	public RgbToYCrCbExpression() {
		super();
		setmyOperands(2);
	}

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("rgbToYCrCb");
		return keywords;
	}

	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return PerlinNoise.colorNoise(getmyExpression().get(0).evaluate(map),
		        getmyExpression().get(1).evaluate(map));

	}

}
