package model.parenexpressions;

import java.util.ArrayList;
import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;
import model.util.ColorCombinations;

/**
 * 
 * @author Kathleen Oshima
 * 
 */
public class ColorExpression extends ParenExpression {

	public ColorExpression() {
		super();
		setmyOperands(3);
	}

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("color");
		return keywords;
	}

	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return ColorCombinations.color(getmyExpression().get(0).evaluate(map),
		        getmyExpression().get(1).evaluate(map), getmyExpression()
		                .get(2).evaluate(map));
	}

}
