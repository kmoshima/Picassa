package model.parenexpressions;

import java.util.ArrayList;
import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;
import model.util.ColorCombinations;

/**
 * 
 * @author Kathleen Oshima
 * 
 */

public class NegateExpression extends ParenExpression {

	/**
	 * Create expression representing the given operation on a constant
	 */

	public NegateExpression() {
		super();
		setmyOperands(1);
	}

	/**
	 * Return the negated version of the input value
	 */
	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return ColorCombinations.negate(getmyExpression().get(0).evaluate(map));
	}

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("neg");
		keywords.add("!");
		return keywords;
	}

}
