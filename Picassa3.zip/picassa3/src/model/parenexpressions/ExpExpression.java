package model.parenexpressions;

import java.util.ArrayList;
import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;
import model.util.ColorCombinations;

/**
 * 
 * @author Kathleen Oshima
 * 
 */
public class ExpExpression extends ParenExpression {

	public ExpExpression() {
		super();
		setmyOperands(2);
	}

	/**
	 * Combine two colors by taking the first value to the second values
	 * exponent
	 */
	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return ColorCombinations.exponent(getmyExpression().get(0)
		        .evaluate(map), getmyExpression().get(1).evaluate(map));
	}

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("exp");
		return keywords;
	}

}
