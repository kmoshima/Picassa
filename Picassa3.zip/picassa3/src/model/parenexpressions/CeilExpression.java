package model.parenexpressions;

import java.util.ArrayList;
import java.util.HashMap;


import model.RGBColor;
import model.mainexpressions.ParenExpression;
import model.util.ColorCombinations;

/**
 * 
 * @author Kathleen Oshima
 * 
 */

public class CeilExpression extends ParenExpression {

	public CeilExpression() {
		super();
		setmyOperands(1);
	}

	@Override
	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add("ceil");
		return keywords;
	}

	@Override
	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return ColorCombinations.ceil(getmyExpression().get(0).evaluate(map));
	}

}
