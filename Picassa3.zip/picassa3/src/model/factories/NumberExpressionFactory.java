package model.factories;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


import model.Expression;
import model.Parser;
import model.mainexpressions.NumberExpression;

/**
 * Parses and creates NumberExpressions
 * 
 * @author Kathleen Oshima
 * 
 */
public class NumberExpressionFactory extends ExpressionFactory {

	private static final Pattern DOUBLE_REGEX = Pattern
	        .compile("(\\-?[0-9]+(\\.[0-9]+)?)|(\\.[0-9]+)");

	@Override
	public boolean findTypeExpression(Parser parser) {
		Matcher pattern = DOUBLE_REGEX
		        .matcher(parser.stringAtCurrentPosition());
		return pattern.lookingAt();
	}

	@Override
	public Expression parseExpression(Parser parser) {
		String input = parser.stringAtCurrentPosition();
		Matcher doubleMatcher = DOUBLE_REGEX.matcher(input);
		doubleMatcher.find(0);
		String numberMatch = input.substring(doubleMatcher.start(),
		        doubleMatcher.end());
		parser.setMyCurrentPosition(numberMatch.length());
		parser.skipWhiteSpace();
		double value = Double.parseDouble(numberMatch);
		return new NumberExpression(value);
	}
}
