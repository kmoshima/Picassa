package model.factories;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.Expression;
import model.Parser;
import model.mainexpressions.VariableExpression;


/**
 * Parses and creates Variable Expressions
 * 
 * @author Kathleen Oshima
 * 
 */
public class VariableExpressionFactory extends ExpressionFactory {

	private static final Pattern XY_REGEX = Pattern.compile("[(a-z)]");

	@Override
	public boolean findTypeExpression(Parser parser) {
		String input = parser.stringAtCurrentPosition();
		Matcher pattern = XY_REGEX.matcher(input);
		return pattern.lookingAt();
	}

	@Override
	public Expression parseExpression(Parser parser) {
		String input = parser.stringAtCurrentPosition();
		Matcher XYMatcher = XY_REGEX.matcher(input);
		XYMatcher.find(0);
		String commandName = input
		        .substring(XYMatcher.start(), XYMatcher.end());
		parser.setMyCurrentPosition(XYMatcher.end());
		parser.skipWhiteSpace();

		return new VariableExpression(commandName);
	}

}
