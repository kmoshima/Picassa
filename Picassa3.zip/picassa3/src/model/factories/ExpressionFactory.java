package model.factories;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.Expression;
import model.Parser;

/**
 * 
 * @author Kathleen Oshima
 * 
 */
public abstract class ExpressionFactory {

	protected boolean regexMatches(Pattern regex, Parser parser) {
		Matcher expMatcher = regex.matcher(parser.stringAtCurrentPosition());
		return expMatcher.lookingAt();
	}

	public abstract boolean findTypeExpression(Parser parser);

	public abstract Expression parseExpression(Parser parser);

}
