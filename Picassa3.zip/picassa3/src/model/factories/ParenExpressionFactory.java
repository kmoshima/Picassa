package model.factories;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



import model.Expression;
import model.Parser;
import model.ParserException;
import model.mainexpressions.ParenExpression;
import model.parenexpressions.AbsExpression;
import model.parenexpressions.AtanExpression;
import model.parenexpressions.AverageExpression;
import model.parenexpressions.CeilExpression;
import model.parenexpressions.ClampExpression;
import model.parenexpressions.ColorExpression;
import model.parenexpressions.CosExpression;
import model.parenexpressions.DivExpression;
import model.parenexpressions.ExpExpression;
import model.parenexpressions.FloorExpression;
import model.parenexpressions.IfExpression;
import model.parenexpressions.LetExpression;
import model.parenexpressions.LogExpression;
import model.parenexpressions.MaxExpression;
import model.parenexpressions.MinExpression;
import model.parenexpressions.MinusExpression;
import model.parenexpressions.ModExpression;
import model.parenexpressions.MulExpression;
import model.parenexpressions.NegateExpression;
import model.parenexpressions.PerlinBWExpression;
import model.parenexpressions.PerlinColorExpression;
import model.parenexpressions.PlusExpression;
import model.parenexpressions.ProductExpression;
import model.parenexpressions.RgbToYCrCbExpression;
import model.parenexpressions.SinExpression;
import model.parenexpressions.SumExpression;
import model.parenexpressions.TanExpression;
import model.parenexpressions.WrapExpression;
import model.parenexpressions.YCrCbtoRGBExpression;

/**
 * Parses and Creates Parenthetic Expressions
 * 
 * @author Kathleen Oshima
 * 
 */
public class ParenExpressionFactory extends ExpressionFactory {
	// ("\\(([a-z]+)"
	private static final Pattern EXPRESSION_BEGIN_REGEX = Pattern
	        .compile("\\( *([a-z|A-Z]+|[\\+\\-\\*\\/\\%\\^\\!])");

	@Override
	public boolean findTypeExpression(Parser parser) {
		String input = parser.stringAtCurrentPosition();
		Matcher pattern = EXPRESSION_BEGIN_REGEX.matcher(input);
		return pattern.lookingAt();
	}

	@Override
	public Expression parseExpression(Parser parser) {
		Matcher expMatcher = EXPRESSION_BEGIN_REGEX.matcher(parser
		        .stringAtCurrentPosition());
		expMatcher.find(0);
		String commandName = expMatcher.group(1);
		parser.setMyCurrentPosition(expMatcher.end());
		ParenExpressionFactory exFac = new ParenExpressionFactory();
		ParenExpression currExp = exFac.getExpression(commandName);
		if (currExp == null)
			throw new ParserException("Operation not available");
		int numOperands = 0;
		while (parser.currentCharacter() != ')') {
			Expression currOperand = parser.parse();
			currExp.add(currOperand);
			numOperands += 1;
		}

		if (currExp.getmyOperands() != -1
		        && numOperands > currExp.getmyOperands())
			throw new ParserException("Too many operands entered");

		parser.skipWhiteSpace();

		if (parser.currentCharacter() == ')') {
			parser.setMyCurrentPosition(1);
			return currExp;

		}
		throw new ParserException("Expected close paren, instead found "
		        + parser.stringAtCurrentPosition());

	}

	public ParenExpression getExpression(String matchWord) {

		ArrayList<ParenExpression> keywords = new ArrayList<ParenExpression>();

		keywords.add(new PlusExpression());
		keywords.add(new MinusExpression());
		keywords.add(new MulExpression());
		keywords.add(new DivExpression());
		keywords.add(new ModExpression());
		keywords.add(new ExpExpression());
		keywords.add(new NegateExpression());
		keywords.add(new ColorExpression());
		keywords.add(new AbsExpression());
		keywords.add(new AtanExpression());
		keywords.add(new CeilExpression());
		keywords.add(new ClampExpression());
		keywords.add(new CosExpression());
		keywords.add(new FloorExpression());
		keywords.add(new LogExpression());
		keywords.add(new PerlinBWExpression());
		keywords.add(new PerlinColorExpression());
		keywords.add(new SinExpression());
		keywords.add(new TanExpression());
		keywords.add(new WrapExpression());
		keywords.add(new RgbToYCrCbExpression());
		keywords.add(new YCrCbtoRGBExpression());
		keywords.add(new LetExpression());
		keywords.add(new SumExpression());
		keywords.add(new ProductExpression());
		keywords.add(new AverageExpression());
		keywords.add(new MinExpression());
		keywords.add(new MaxExpression());
		keywords.add(new IfExpression());

		for (ParenExpression exp : keywords) {
			if (exp.getKeyword().contains(matchWord))
				return exp;
		}
		return null;
	}

}
