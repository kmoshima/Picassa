package model;

import java.util.ArrayList;

import model.factories.ExpressionFactory;
import model.factories.NumberExpressionFactory;
import model.factories.ParenExpressionFactory;
import model.factories.VariableExpressionFactory;

/**
 * Parses a string into an expression tree based on rules for arithmetic.
 * 
 * Due to the nature of the language being parsed, a recursive descent parser is
 * used http://en.wikipedia.org/wiki/Recursive_descent_parser
 * 
 * @author Kathleen Oshima
 */

public class Parser {

	private int myCurrentPosition;
	private String myInput;

	/**
	 * Converts given string into expression tree.
	 * 
	 * @param input
	 *            expression given in the language to be parsed
	 * @return expression tree representing the given formula
	 */
	public Expression makeExpression(String input) {
		myInput = input;
		myCurrentPosition = 0;
		Expression result = parse();
		skipWhiteSpace();
		if (notAtEndOfString()) {
			throw new ParserException(
			        "Unexpected characters at end of the string: "
			                + myInput.substring(myCurrentPosition),
			        ParserException.Type.EXTRA_CHARACTERS);
		}
		return result;
	}

	/**
	 * Determines which type of expression to instantiate and calls on the
	 * appropriate factory to parse
	 */
	public Expression parse() {

		ArrayList<ExpressionFactory> expressionTypes = new ArrayList<ExpressionFactory>();

		expressionTypes.add(new ParenExpressionFactory());
		expressionTypes.add(new VariableExpressionFactory());
		expressionTypes.add(new NumberExpressionFactory());

		skipWhiteSpace();
		for (ExpressionFactory exp : expressionTypes) {
			if (exp.findTypeExpression(this))
				return (exp.parseExpression(this));
		}
		throw new ParserException("Unparsable expression: "
		        + stringAtCurrentPosition());
	}

	public void skipWhiteSpace() {
		while (notAtEndOfString() && Character.isWhitespace(currentCharacter())) {
			myCurrentPosition++;
		}
	}

	public int setMyCurrentPosition(int num) {
		return myCurrentPosition += num;
	}

	public char currentCharacter() {
		return myInput.charAt(myCurrentPosition);
	}

	public boolean notAtEndOfString() {
		return myCurrentPosition < myInput.length();
	}

	public String stringAtCurrentPosition() {
		return myInput.substring(myCurrentPosition);
	}
}
