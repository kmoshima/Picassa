package model.util;

import model.RGBColor;

/**
 * Modifies or combines two colors by combining their components.
 * 
 * This is a separate class from color since it is just one set of ways to
 * combine colors, many may exist and we do not want to keep modifying the
 * RGBColor class.
 * 
 * @author Kathleen Oshima
 */
public class ColorCombinations {

	public static RGBColor add(RGBColor left, RGBColor right) {
		return new RGBColor(left.getRed() + right.getRed(), left.getGreen()
		        + right.getGreen(), left.getBlue() + right.getBlue());
	}

	public static RGBColor subtract(RGBColor left, RGBColor right) {
		return new RGBColor(left.getRed() - right.getRed(), left.getGreen()
		        - right.getGreen(), left.getBlue() - right.getBlue());
	}

	public static RGBColor multiply(RGBColor left, RGBColor right) {
		return new RGBColor(left.getRed() * right.getRed(), left.getGreen()
		        * right.getGreen(), left.getBlue() * right.getBlue());
	}

	public static RGBColor divide(RGBColor left, RGBColor right) {
		return new RGBColor(left.getRed() / right.getRed(), left.getGreen()
		        / right.getGreen(), left.getBlue() / right.getBlue());
	}

	public static RGBColor modulus(RGBColor left, RGBColor right) {
		return new RGBColor(left.getRed() % right.getRed(), left.getGreen()
		        % right.getGreen(), left.getBlue() % right.getBlue());
	}

	public static RGBColor exponent(RGBColor left, RGBColor right) {
		return new RGBColor(Math.pow(left.getRed(), right.getRed()), Math.pow(
		        left.getGreen(), right.getGreen()), Math.pow(left.getBlue(),
		        right.getBlue()));
	}

	public static RGBColor negate(RGBColor value) {
		return new RGBColor(-value.getRed(), -value.getGreen(),
		        -value.getBlue());
	}

	public static RGBColor color(RGBColor left, RGBColor middle, RGBColor right) {
		return new RGBColor(left.getRed(), middle.getGreen(), right.getBlue());
	}

	public static RGBColor floor(RGBColor value) {
		return new RGBColor(Math.floor(value.getRed()), Math.floor(value
		        .getGreen()), Math.floor(value.getBlue()));
	}

	public static RGBColor ceil(RGBColor value) {
		return new RGBColor(Math.ceil(value.getRed()), Math.ceil(value
		        .getGreen()), Math.ceil(value.getBlue()));
	}

	public static RGBColor abs(RGBColor value) {
		return new RGBColor(Math.abs(value.getRed()),
		        Math.abs(value.getGreen()), Math.abs(value.getBlue()));
	}

	public static RGBColor clamp(RGBColor value) {
		if (value.getBlue() > 1)
			return new RGBColor(1, 1, 1);
		if (value.getBlue() < -1)
			return new RGBColor(-1, -1, -1);
		return value;
	}

	public static RGBColor wrap(RGBColor value) {
		if (value.getBlue() > 1 || value.getBlue() < -1)
			return new RGBColor(value.getRed() % 1.0, value.getGreen() % 1.0,
			        value.getBlue() % 1.0);
		return value;
	}

	public static RGBColor sin(RGBColor value) {
		return new RGBColor(Math.sin(value.getRed()),
		        Math.sin(value.getGreen()), Math.sin(value.getBlue()));
	}

	public static RGBColor cos(RGBColor value) {
		return new RGBColor(Math.cos(value.getRed()),
		        Math.cos(value.getGreen()), Math.cos(value.getBlue()));
	}

	public static RGBColor tan(RGBColor value) {
		return new RGBColor(Math.tan(value.getRed()),
		        Math.tan(value.getGreen()), Math.tan(value.getBlue()));
	}

	public static RGBColor atan(RGBColor value) {
		return new RGBColor(Math.atan(value.getRed()), Math.atan(value
		        .getGreen()), Math.atan(value.getBlue()));
	}

	public static RGBColor log(RGBColor value) {
		return new RGBColor(Math.log(value.getRed()),
		        Math.log(value.getGreen()), Math.log(value.getBlue()));
	}

	public static RGBColor average(RGBColor left, RGBColor right) {
		return new RGBColor((left.getRed() + right.getRed()) / 2,
		        (left.getGreen() + right.getGreen()) / 2,
		        (left.getBlue() + right.getBlue()) / 2);
	}

	public static RGBColor min(RGBColor left, RGBColor right) {
		return new RGBColor(Math.min(left.getRed(), right.getRed()), Math.min(
		        left.getGreen(), right.getGreen()), Math.min(left.getBlue(),
		        right.getBlue()));
	}

	public static RGBColor max(RGBColor left, RGBColor right) {
		return new RGBColor(Math.max(left.getRed(), right.getRed()), Math.max(
		        left.getGreen(), right.getGreen()), Math.max(left.getBlue(),
		        right.getBlue()));
	}

}
