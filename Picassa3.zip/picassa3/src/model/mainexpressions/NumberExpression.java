package model.mainexpressions;

import java.util.ArrayList;

import java.util.HashMap;

import model.Expression;
import model.RGBColor;

/**
 * 
 * @author Kathleen Oshima
 * 
 */
public class NumberExpression extends Expression {

	private RGBColor myColor;

	public NumberExpression(double num) {
		myColor = new RGBColor(num);
	}

	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return myColor;
	}

	public ArrayList<String> getKeyword() {
		return null;
	}

}
