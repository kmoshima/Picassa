package model.mainexpressions;

import java.util.ArrayList;
import java.util.List;

import model.Expression;

/**
 * 
 * @author Kathleen Oshima
 * 
 */
public abstract class ParenExpression extends Expression {

	private int myOperands;
	private List<Expression> myExpressions;

	public ParenExpression() {
		myExpressions = new ArrayList<Expression>();
	}

	public void add(Expression exp) {
		myExpressions.add(exp);
	}

	public int getmyOperands() {
		return myOperands;
	}

	public List<Expression> getmyExpression() {
		return myExpressions;
	}

	public int setmyOperands(int num) {
		return myOperands = num;
	}

}
