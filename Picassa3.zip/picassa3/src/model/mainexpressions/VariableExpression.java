package model.mainexpressions;

import java.util.ArrayList;
import java.util.HashMap;

import model.Expression;
import model.RGBColor;

/**
 * 
 * @author Kathleen Oshima
 * 
 */
public class VariableExpression extends Expression {

	private String myVariable;

	public VariableExpression(String keyword) {
		myVariable = keyword;
	}

	public RGBColor evaluate(HashMap<String, RGBColor> map) {
		return map.get(myVariable);
	}

	public ArrayList<String> getKeyword() {
		ArrayList<String> keywords = new ArrayList<String>();
		keywords.add(myVariable);
		return keywords;
	}

}
